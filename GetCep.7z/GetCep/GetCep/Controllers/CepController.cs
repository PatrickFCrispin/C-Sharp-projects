﻿using GetCep.Models;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace GetCep.Controllers
{
    public class CepController
    {
        //Altere o cep para realizar a pesquisa. Valores aceitos: 93180000 | 93180-000
        readonly string cep = "93180000";
        string content = null;

        async Task ConnectToApiAndGetCep()
        {
            try
            {
                HttpClient httpClient = new HttpClient();

                string url = $"https://viacep.com.br/ws/{cep}/json";

                HttpResponseMessage responseMessage =
                    await httpClient.GetAsync(url);

                if (responseMessage.IsSuccessStatusCode)
                {
                    content = await responseMessage.Content.ReadAsStringAsync();
                }
            } 
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public async Task UpdateDadosCepAsync()
        {
            try
            {
                await ConnectToApiAndGetCep();

                var cepSchema = JsonConvert.DeserializeObject<CepSchema>(content);

                if (cepSchema.Cep == null)
                {
                    Console.WriteLine("Cep não encontrado.");
                    return;
                }

                Console.WriteLine("*** Resultado ***");
                Console.WriteLine($"Cep: {cepSchema.Cep}");
                Console.WriteLine($"Logradouro: {cepSchema.Logradouro}");
                Console.WriteLine($"Complemento: {cepSchema.Complemento}");
                Console.WriteLine($"Bairro: {cepSchema.Bairro}");
                Console.WriteLine($"Localidade: {cepSchema.Localidade}");
                Console.WriteLine($"UF: {cepSchema.Uf}");
                Console.WriteLine($"IBGE: {cepSchema.Ibge}");
                Console.WriteLine($"Gia: {cepSchema.Gia}");
                Console.WriteLine($"DDD: {cepSchema.Ddd}");
                Console.WriteLine($"Siafi: {cepSchema.Siafi}");
            } 
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
