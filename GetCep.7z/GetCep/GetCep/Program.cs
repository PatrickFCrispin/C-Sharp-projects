﻿using System.Threading.Tasks;
using GetCep.Controllers;

namespace GetCep
{
    class Program
    {
        static async Task Main(string[] args)
        {
            CepController cepController = new CepController();
            await cepController.UpdateDadosCepAsync();
        }
    }
}
